import React from 'react';
import { ChevronDown } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="h-16 bg-[#1e293b] text-white flex items-center justify-between px-6 shadow-md w-full">
      {/* Left side empty or breadcrumbs if needed, keeping it empty to match image */}
      <div className="flex-1"></div>

      {/* Right side: User Profile */}
      <div className="flex items-center gap-3 cursor-pointer hover:bg-white/10 p-2 rounded-lg transition-colors">
        <div className="flex flex-col items-end">
          <span className="font-semibold text-sm leading-tight">Giám sát</span>
          <div className="flex items-center gap-1 text-xs text-green-400">
            <span className="w-2 h-2 rounded-full bg-green-500 inline-block"></span>
            <span className="text-gray-300">antony - HCM - KCN</span>
          </div>
        </div>
        <div className="w-10 h-10 rounded-full bg-gray-400 overflow-hidden border-2 border-white/20">
           <img src="https://picsum.photos/200/200" alt="Avatar" className="w-full h-full object-cover" />
        </div>
        <ChevronDown className="w-4 h-4 text-gray-400" />
      </div>
    </header>
  );
};