import React from 'react';
import { 
  LayoutDashboard, 
  ExternalLink, 
  Settings, 
  Users, 
  Droplets, 
  Briefcase, 
  Database, 
  Disc,
  UserCog,
  ChevronLeft,
  ChevronRight,
  Menu
} from 'lucide-react';

interface SidebarProps {
  isCollapsed: boolean;
  onToggle: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isCollapsed, onToggle }) => {
  return (
    <div 
      className={`
        bg-slate-50 h-screen flex flex-col border-r border-gray-200 flex-shrink-0 font-medium text-sm text-slate-600
        transition-all duration-300 ease-in-out relative
        ${isCollapsed ? 'w-20' : 'w-64'}
      `}
    >
      {/* Logo Area */}
      <div className={`h-16 flex items-center border-b border-gray-100 bg-white overflow-hidden whitespace-nowrap ${isCollapsed ? 'justify-center px-0' : 'px-6'}`}>
        <span className="text-xl font-bold text-slate-800 flex items-center gap-2">
           {isCollapsed ? (
             <LayoutDashboard className="w-6 h-6 text-slate-800" />
           ) : (
             <>
               EzPlatform <LayoutDashboard className="w-5 h-5 text-slate-400" />
             </>
           )}
        </span>
      </div>

      <div className="flex-1 overflow-y-auto overflow-x-hidden py-4 scrollbar-hide">
        {/* Section 1: Embedded Sites */}
        <div className={`mb-2 transition-all duration-300 ${isCollapsed ? 'px-2' : 'px-6'}`}>
          <h3 className={`text-xs font-bold text-slate-900 mb-3 uppercase tracking-wider transition-opacity duration-200 ${isCollapsed ? 'opacity-0 h-0 overflow-hidden' : 'opacity-100'}`}>
            Embedded Sites
          </h3>
          <ul className="space-y-1">
            <SidebarItem 
              icon={<Briefcase className="w-5 h-5 text-sky-600 flex-shrink-0" />} 
              label="ezWork" 
              isCollapsed={isCollapsed} 
              hasExternalLink 
            />
            <SidebarItem 
              icon={<Droplets className="w-5 h-5 text-blue-500 flex-shrink-0" />} 
              label="ezWater" 
              isCollapsed={isCollapsed} 
              hasExternalLink 
            />
            <SidebarItem 
              icon={<Database className="w-5 h-5 text-red-500 flex-shrink-0" />} 
              label="Datasite" 
              isCollapsed={isCollapsed} 
              hasExternalLink 
            />
             <SidebarItem 
              icon={<Disc className="w-5 h-5 text-slate-400 flex-shrink-0" />} 
              label="Mode 4" 
              isCollapsed={isCollapsed} 
              hasExternalLink 
            />
          </ul>
        </div>

        <div className="border-t border-slate-200 my-4 mx-4"></div>

        {/* Section 2: Quản lý */}
        <div className={`transition-all duration-300 ${isCollapsed ? 'px-2' : 'px-6'}`}>
          <h3 className={`text-xs font-bold text-slate-900 mb-3 uppercase tracking-wider transition-opacity duration-200 ${isCollapsed ? 'opacity-0 h-0 overflow-hidden' : 'opacity-100'}`}>
            Quản lý
          </h3>
          <ul className="space-y-1">
            <SidebarItem 
              icon={<Settings className="w-5 h-5 text-slate-500 flex-shrink-0" />} 
              label="Cấu hình thông tin cơ bản" 
              isCollapsed={isCollapsed} 
            />
            <SidebarItem 
              icon={<Users className="w-5 h-5 text-slate-500 flex-shrink-0" />} 
              label="Cấu hình quyền người dùng" 
              isCollapsed={isCollapsed} 
            />
            <SidebarItem 
              icon={<UserCog className="w-5 h-5 text-slate-600 flex-shrink-0" />} 
              label="Quản lý tài khoản" 
              isActive
              isCollapsed={isCollapsed} 
            />
          </ul>
        </div>
      </div>

      {/* Toggle Button */}
      <button 
        onClick={onToggle}
        className="h-12 border-t border-gray-200 flex items-center justify-center hover:bg-slate-100 text-slate-500 transition-colors focus:outline-none"
        title={isCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
      >
        {isCollapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
      </button>
    </div>
  );
};

interface SidebarItemProps {
  icon: React.ReactNode;
  label: string;
  hasExternalLink?: boolean;
  isActive?: boolean;
  isCollapsed: boolean;
}

const SidebarItem: React.FC<SidebarItemProps> = ({ icon, label, hasExternalLink, isActive, isCollapsed }) => {
  return (
    <li 
      className={`
        flex items-center group cursor-pointer py-2 rounded-md transition-colors h-10
        ${isActive ? 'bg-slate-200 text-slate-900 font-semibold' : 'hover:bg-slate-200'}
        ${isCollapsed ? 'justify-center px-0' : 'justify-between px-2'}
      `}
      title={isCollapsed ? label : undefined}
    >
      <div className={`flex items-center transition-all duration-300 ${isCollapsed ? 'justify-center w-full gap-0' : 'gap-3'}`}>
        {icon}
        <span className={`whitespace-nowrap transition-all duration-300 ${isCollapsed ? 'w-0 opacity-0 overflow-hidden' : 'w-auto opacity-100'}`}>
          {label}
        </span>
      </div>
      
      {hasExternalLink && !isCollapsed && (
        <ExternalLink className="w-3 h-3 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
      )}
    </li>
  );
};