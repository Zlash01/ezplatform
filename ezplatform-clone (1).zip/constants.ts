import { Account } from './types';

export const MOCK_ACCOUNTS: Account[] = [
  {
    id: 1,
    username: "Giám sát",
    fullName: "Giám sát",
    createdAt: "2024-02-10 10:00",
    company: "KCN Linh Truong",
    position: "Giám sát"
  },
  {
    id: 2,
    username: "admin_kcn",
    fullName: "Nguyễn Văn A",
    createdAt: "2024-02-11 08:30",
    company: "KCN Linh Truong",
    position: "Quản trị viên"
  },
  {
    id: 3,
    username: "operator_01",
    fullName: "Trần Thị B",
    createdAt: "2024-02-12 14:15",
    company: "KCN Linh Truong",
    position: "Vận hành"
  }
];

export const APP_TITLE = "EzPlatform";
