import React from 'react';

export interface Account {
  id: number;
  username: string;
  fullName: string;
  createdAt: string;
  company: string;
  position: string;
}

export interface SidebarItem {
  label: string;
  icon?: React.ReactNode;
  hasExternalLink?: boolean;
  isActive?: boolean;
}

export interface SidebarSection {
  title?: string;
  items: SidebarItem[];
}