import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { AccountTable } from './components/AccountTable';
import { MOCK_ACCOUNTS } from './constants';

const App: React.FC = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const AUTO_COLLAPSE_DURATION = 30000; // 30 seconds for demo purposes

  // Function to reset the inactivity timer
  const resetInactivityTimer = useCallback(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
    }

    // Only set the timer if the sidebar is currently expanded
    if (!isSidebarCollapsed) {
      timerRef.current = setTimeout(() => {
        setIsSidebarCollapsed(true);
      }, AUTO_COLLAPSE_DURATION);
    }
  }, [isSidebarCollapsed]);

  // Setup event listeners for user activity
  useEffect(() => {
    const events = ['mousemove', 'keydown', 'click', 'scroll', 'touchstart'];
    
    const handleActivity = () => {
      resetInactivityTimer();
    };

    // Attach listeners
    events.forEach(event => {
      window.addEventListener(event, handleActivity);
    });

    // Initial timer start
    resetInactivityTimer();

    // Cleanup
    return () => {
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
      events.forEach(event => {
        window.removeEventListener(event, handleActivity);
      });
    };
  }, [resetInactivityTimer]);

  const toggleSidebar = () => {
    setIsSidebarCollapsed(prev => !prev);
  };

  return (
    <div className="flex h-screen bg-[#f1f5f9] overflow-hidden">
      {/* Sidebar with props */}
      <Sidebar 
        isCollapsed={isSidebarCollapsed} 
        onToggle={toggleSidebar} 
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 transition-all duration-300">
        <Header />
        
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-[1600px] mx-auto">
            <h1 className="text-xl font-bold text-gray-800 mb-6">Quản lý tài khoản</h1>
            
            <AccountTable data={MOCK_ACCOUNTS} />
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;